import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-nav',
    templateUrl: 'nav.component.html'
})
export class NavigationBarComponent implements OnInit {

    constructor() { }

    ngOnInit() { 

    }
  
}